ep2IMG ;CKW/ESC i5dec22 umbr./ rMP1/ ;20221205-52; grFL, itemFL
;
;
top    ;
       S itemFL="runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)"
       S grFL="runa,ruab,ruty,ruLst,nLst,tokCL,nLCL,Lna,rde_GRk(ruid)"
       ;
       D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)")
       D T^kfm("grFL:runa,ruab,ruty,ruLst,nLst,tokCL,nLCL,Lna,rde_GRk(ruid)")
       Q
;*
IKILL  KILL SCF,GRk,GRx
       S GRk=0
       Q
;*
