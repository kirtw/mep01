ep2PAR  ;CKW/ESC i31oct22 ;20221202-46;Parse INc(),INty  into Gr Grammar...
;
;  GRi(ruid)
;  Gxi(<rule-name>,gi)=isq  ;  ~ left-hand-side name index, mult rules, gi
;
;  INc(Ip)=literal input chars, from Ins, a string of chars
;
;  SCF items or rules (aka dotted-rule, item, )
;   ruLst:   _5 is ruLst a comma list of tokens- rule-names or terminal-set-names)
;   dot:  a ptr into the current ruLst comma pieces
;   Ips   is the input start pointer, Ips, into Ins (~input)
;   IPe   is the end-ptr into Ins, implicitly==Si in Lua
;   ruby
;   frm  What function created  {PRED, SCAN, COMP, Init }
;   ruC   Input chars consumed between IPs & IPe
;    
top    W !!,"Magic  Parsing !"
       D initSC
       S Wmo="SSC"  ; "I1,BLp1,BLp2,tokR1,SSC,SCe" ; {I1,BLp1,BLp2,tokR1,SSC,SCe}
       D main
       D WSC^ep2W  ; Full Table
       I $G(devlog)'="" USE $P D WSC^ep2W  ; also to $P
       Q
       ;
main   ; loop thru INputs, Ip BUILD analog
       S SSq=0
       F Sbi=1:1 Q:$D(SCF(Sbi))=0  DO  ;
         .I Wmo["BLp1" W !!,"BUILD Outer Loop1 [",Sbi,"] ",!
         .F Sbj=1:1 Q:$D(SCF(Sbi,Sbj))=0   D BI1  D EL2 ;
       I Wmo["BLp1" W:$X ! W "End BUILD Outer Loop1 [",Sbi,"] ",!
       Q
;*
FL  D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)") 
    Q
;* Si,Sj
BI1    S Si=Sbi,Sj=Sbj
       D GFL^kfm(itemFL) ; Si,Sj : ru*...
         I Wmo["I1" D Witem^ep2W("BI1")
       D getR1^ep2W ; dot, ruLst : tokR1, tokTy
        ; rule loop, item-loop, 
        I Sbi=1,Sbj=8 D b^dv("Log pre 2.9 ","dot,ruLst,tokR1,tokTy,IPs,IPe")
        ;
       D ^dv("Log BI1+8 P-S-C choice","Sbi,Sbj,tokR1,tokTy,ruLst,dot,ruab,IPs,IPe")
       I tokR1=""!(tokTy="C") S trc="C:" D COMPLETE(Sbi,Sbj,IPs,runa)  Q  ; 
       I tokTy="T" S trc="S:" D SCAN(Sbi,Sbj,tokR1)  Q  ; token with + is terminal
       ; tokTy="R"
       I tokTy'="R" D b^dv("Err tokTy","tokTy,tokR1,ruab,dot,ruLst")
       S trc="P:" D PRED(Sbi,Sbj,tokR1) Q ;inside loop chart items/rules
       D b^dv("Err illegal rule.?","tokR1,Sbi,Sbj")
       Q
;*   end each inside loop
EL2    W:$X ! W "End inner Bloop ",Sbi,",",Sbj,"   trace:",$G(trc),"  "
       ;I $G(SCF(Sbi+1))="" S SCF(Sbi+1)=0
       I Sbi=2,Sbj=9 D ^dv("Log post 2.9 ","tokR1,dot,ruLst,IPs,IPe")
       Q
;*         
;*  Sbi, Sbj        
PRED(Spi,Spj,tokP)  ;NEW Spj
       W:$X ! W "#",SSq," PRED find '",$G(tokP),"' in Gxi-> gi -> ruid",!
       I $G(tokP)="" D b^dv("Err tokR1 should not be null here","tokP,tokR1,Sbi,Sbj,Spi") Q
       I Spi'=Sbi D b^dv("Maybe Err ?","Sbi,Spi,Spj")
       I $D(Gxi(tokP))=0 D bug^dv("Err tokR1 not in Gxi(tokR1/P","tokP") Q
       ;For every grammar rule with name=tokP- runa,gi -> ruid
       F gi=1:1 Q:$D(Gxi(tokP,gi))=0   D NwP
       ;D PZE
       Q
;*  try new dot,IPs,ruid from
NwP    ; tokP, gi > ruid /GR record
       S ruid=$G(Gxi(tokP,gi))
         I ruid="" D b^dv("Err ruid from Gxi(tokR1)","ruid,tokR1,gi") Q
       D GFL^kfm("ruab,ruLst",grFL)  ; ruid : ruLst, ruab
       S dot=1
       S ruby="PRED"         
       S frm="Pred fr:"_Spi_"."_Spj
       ;S IPs=Spi  ; IPs item.start
       I IPe'=Spi-1 D ^dv("Err Inconsistenct IPe,Spi","IPe,Sci,Si,Sj")
       ;S IPe=Spi-1  ; IPe is implicit always == Si-1?
       D SSC(Spi,frm) ; save in this Sbi~Spi State (same), if not dupl, Sbi at end
       Q
;*
    D NFL^kfm(itemFL)
    D T^kfm("grFL:runa,ruab,ruty,ruLst,nLst,tokCL,nLCL,Lna,rde_GRk(ruid)")
    D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)")
;*
;* Sbi,Sbj  @itemGL  : mod SSC
SCAN(Ssi,Ssj,tokR1) ;I Ssi=1 D ^dv("No Input Si=1","Ssi,Ssj,tokR1") Q
       S IPc=Ssi
       S C=INc(IPc) I C="" D b^dv("Err C ","C,IPc,Ssi,Ssj") Q
       ;
       S ruid=$G(Gxi(tokR1,1))  ;only one gi for terminal tokens
         I ruid="" D b^dv("Err Scan finding ruid from tokR1","tokRa,tokTy,ruid") Q
       S tokCL=$G(GRk(ruid,"tokCL"))
         I tokCL="" D b^dv("Err Char tokCL","tokCL,tokR1,C")
       ;
       D ^dv("Log test sc ","C,Ssi,Ssj,tokR1")
       I tokCL'[C  DO  Q  ;Punt, non-terminal/char match
         .D ^dv("Log '"_C_"' not in "_tokR1,"C,CL,tokR1,Ssi,Ssj") 
       ;Here matched terminal, C in tokCL, ITcl(tokR1)
       S dot=dot+1
       S frm="SCAN term '"_C_"'  fr:"_Ssi_"."_Ssj
       S Ssi2=Ssi+1
       S IPe=Ssi2-1 ; ?
       D SSC(Ssi2,frm)  ; Svj
       I Wmo["SCe" W:$X ! W " * end scan ",Ssi,".",Ssj," -- ",Ssi2,".",Svj,!
       Q
;*
COMPLETE(Sci,Scj,FIPs,Fna)  ;  S2i Fna~Found runa, FIPs~FOund IPs-> where to search
       ;item  finished
       D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)")
       S S2i=FIPs I $G(Fna)="" D b^dv("Err Found runa null","Fna,runa,Sci,Scj")
       I Sci'=S2i D ^dv(" +++ C Gotcha ","Sci,S2i,IPs,Fna")
       S Sc2i=FIPS
       F Sc2j=1:1 Q:$D(SCF(Sc2i,Sc2j))=0  DO  ;  vs While, SCF(Sc2i) chgs?
         .S Si=Sc2i,Sj=Sc2j
         .D GFL^kfm(itemFL) ; Si,Sj : @itemFL
         .I tokR1'=Fna Q         
         .I Wmo["Comp" W:$X ! W " * + Comp st ",S2i,".",Sc2j," .",dot,"  ",?40,ruLst,!         
         .S dot=dot+1
         .S frm="Cmplt fr:"_Sci_"."_Scj
         .S ruby="COMP"      
         .S Sc3i=S2i+1,IPe=Sc3i
         .D SSC(Sc3i,frm)  S Sc3j=Svj  ; where new stored
         .D ^dv("Log one new C item ","Sci,Scj,Sc2i,Sc2j,Sc3i,Sc3j,dot,ruLst")
         .;W:$X ! W " * + Comp end-new ",Sci,"/",Scj," .",dot,"  ",?40,ruLst,!
       Q
;*
;*  Save in SCF
;Analog of Append and Unsafe-Append (sic,sic) functions
;  Dont duplicate, loop til empty, punt if dupl
;* @itemFL modified : SCF(Svi,Svj),  Svj, 'EQ => new at Svj/ EQ rej dupl
SSC(Svi,frm)  ;no NEW Svj- returned for debugging
       ;Find end AND ck for dupl to Punt on EQ~dupl
       F Svj=1:1 Q:$D(SCF(Svi,Svj))=0   DO  Q:EQ  
         .S EQ=1 F vn="ruid","dot","IPs","" Q:vn=""  I @vn'=$G(SCF(Svi,Svj,vn)) S EQ=0 Q
         .;D ^dv("Log EQ","EQ,vn,Svi,Svj,ruid,dot,IPs,frm,trc,ruby")
       ;Punt if duplicate found:
       I EQ  DO  Q  ; punt when dupl exists already
          .S log="Rej Dupl "_Svi_"."_Svj_"  #"_ruid_", ."_dot_" s:"_IPs_"  frm:"_frm
          .I Wmo["RejDup" W:$X ! W log,!
       ; Non-duplicate, save-
       S SSq=SSq+1 ;Serial items       
       S Si=Svi,Sj=Svj
       D getR1^ep2W ; dot, rulst : tokR1, tokTy
       ; Svj is new empty node, ie SCF(Svi,Svj    
       D SFL^kfm("ruid,dot,IPs,ruab,ruLst,frm,tokR1,tokTy",itemFL) ; Si=Svi, Sj=Svj new at end
       D TEX
       S log="SSC: q"_SSq_"  "_Si_"."_Sj_"["_IPs_"-"_IPe_"]  ."_dot_" #"_ruid_" "_frm
       W:$X ! W log,!
       ;audit-
         ;I IPe'=(Svi-1) D b^dv("Err explicit IPe vs Svi-1","tIPe,Svi,Svj")
       I Wmo["SSC" DO  ;
         .W:$X ! W "SSC New/nonDup SCF(",Svi,".",Svj,") = "
         .W ?40,ruab,"  '",ruLst,"' ",!
       Q:$Q "New:"_Svi_"."_Svj_"  "_ruab Q
       ;
;*
TEX    NEW vi,vn,XL
       S X="",XL="ruid,dot,IPs" F vi=1:1:$L(XL,",") S vn=$P(XL,",",vi) S $P(X,"_",vi)=@vn
       S ^DSF(1,SSq)=X
       S Z=$G(^DSF(0,SSq))
       I Z'="",X'=Z D b^dv("Err SSC vs ref","SSq,X,Z")
       Q
;*
PZE(M,VL) USE $P W !!," *****  "
      S VL=$G(VL) I VL="" S VL="mrid"
      I $G(M)'="" D ^dv(M,VL)
      R !,"Pause (ret) . for Dir Mode",!,":",X
      I $G(VL)="" S VL="Sbi,Sbj,ruab,tokR1,tokTy"
      I X["." D b^dv("Pause ",VL)
      Q
 ;*
initSC KILL SCF
       D ^ep2IMG  ; grFL, itemFL
    D T^kfm("grFL:runa,ruab,ruty,ruLst,nLst,tokCL,nLCL,Lna,rde_GRk(ruid)")
    D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)")
       D NFL^kfm(itemFL)
       S Si=1,Sj=1,ruid=1 D GFL^kfm(grFL) ; ruid, Sum.1, ruLst
       S frm="Init"  ; Initial conditions
       S dot=1,IPs=1,IPe=0,SSq=1
       D SFL^kfm(itemFL)  ; Si,Sj   Alt to SSC, no need to ck dupl
       ;D ^dv("Log Init 1.1","ruLst")
       S ruid=2 D GFL^kfm(grFL)
       S dot=1,IPs=1,IPe=0,SSq=2
       S Sj=2 D SFL^kfm(itemFL)
       ;D ^dv("Log Init 1.2","ruLst")       
       Q
;*       
; GWUSCO
;i, Si, Sbi, Spi, Sci, Ssi, Swi,   Pass as args, dont bleed up
;j, Sj, Sbj, Spj, Scj, Ssk, Swj    Some NOT arg, just reuse, eg SSC  Svi,Svj
; i,Si~Ip ~IPc  pointer to INc()  inPointer 
;
; SC State Chart  sic 
; SCF(Si,Sj)  @itemFL 
;
