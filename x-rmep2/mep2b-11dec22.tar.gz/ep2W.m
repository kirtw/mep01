ep2W  ;CKW/ESC i31oct22 rMP1/ ;20221031-60;Write sr for parser data structures
;
;
;
;*
top    D b^dv("No top entry -^"_$T(+0),"ruid")
;*
;*  dot, ruLst : nLst, tokR1, tokTy {R,T, C}
getR1  I $G(dot)="" D bug^dv Q
       I 'dot D b^dv("dot NOT zero","dot,ruid,ruab") Q
       ; dot=1 init, dot points to first in ruLst
       I $G(ruLst)="" S Q="Err no ruLst arg getR1^"_$T(+0) D b^dv(Q,"Q,dot") Q
       S nLst=$L(ruLst,",")
       S tokR1=$P(ruLst,",",dot)
       I tokR1="" DO  ;
         .S tokTy="C"
         .I dot'=(nLst+1) D b^dv("C dot ?","dot,nLst,ruLst,tokR1,tokTy")
       I tokR1'="" S tokTy="R" I $E(tokR1)?1U S tokTy="T"
        I Wmo["tokR1" DO  ;
           .W:$X ! W "sr tokR1 ",Si,".",Sj," .",dot," in ",ruLst,"' "
           .W "  ->",tokR1," ty:",tokTy,!
       Q
;*  : LST  
FO(dot,ruLst) D bug^dv Q
       S LST="" F ti=1:1:$L(ruLst,",") DO  ;
         .I ti<0 S LST=LST_"      " Q
         .I ti=dot S LST=LST_"  *   "  ;continue
         .S tok=$P(ruLst,",",ti) 
         .I tok="" S tok="      "
         .S tok=tok_$E("       ",$L(tok),6) I $L(tok)'=7 D b^dv("Err pad","tok,dot,ri")
         .S LST=LST_tok
       Q
;*  GRk(ruid)=@grFL,   Gxi(runa,gi)=ruid ?
;
; This is all static after init setup by IG
WGR    W !!,"Grammar GRk() rules-"
       NEW ruid,ruab,ina,rugi,ruab,ti,rde,runa,ruLst,tok
       D T^kfm("grFL:runa,ruab,ruty,ruLst,nLst,tokCL,nLCL,Lna,rde_GRk(ruid)")
       F ruid=1:1:GRk   DO  ;
         .D GFL^kfm(grFL)
         .S LST=ruLst_tokCL ; either or
         .D WG1
       Q
;*  ruid, @grFL 
WG1    W:$X ! W ruid,"  ",?4     NEW x
       W runa,".",rugi,"/  ",ruid," "
       W ?14," -> ",LST,"  "
       I naLua'="" W ?40,naLua,"  "
       I rde'="" S x=40 S:$X>40 x=55 W ?x,rde," "
       W !
       Q
;*
;*  SCF()  Write all, Lua Loup Compatible output lines
WSC(M) W !!,"Complete Table-",!!
       NEW Si,Sj
       F Si=1:1 Q:$D(SCF(Si))=0  D WS(Si)
       W !!
       Q
;*  SCF(Si)
WS(Si,M)  W:$X ! W !,"     ====++ ",Si," ++==== SE:",Si-1,"  ",!
    D T^kfm("itemFL:runa,ruab,ruid,SSq,IPs,IPe,dot,ruLst,tokR1,tokTy,ruby,frm_SCF(Si,Sj)")
       NEW runa,ruab,IPs,IPe,dot,ruLst,nLst,tokR1,ruDone,ruby,rufrm
       F Sj=1:1 Q:$D(SCF(Si,Sj))=0   DO  ;
         .D GFL^jfm("ruid,ruab,ruLst,dot,IPs,IPe,tokR1,tokTy,frm",itemFL) ;
         .D Witem
       W !
       Q

;*  Write One item  Maximize Utility mep  vs WS ala Earley/LoupLua
;*  Si,Sj, @itemFL  ruid,ruab,ruLst,dot,IPs,   IPe,tokR1,tokTy
Witem(M)  NEW i,tok
       D Itab("10,10,5,8,8,8,12,10,10") ; : tb(i) from width list
       S M=$G(M) I M'="" S M=M_": " 
       W:$X ! W M,SSq," ",?3,Si,".",Sj," ",ruab,"/",ruid,"  " 
       ;D FO(dot,ruLst) ; : LST
       ;S FL="runa,IPs,IPe,dot,LST,...
       W ?tb(2)," -> "
       W "{",$G(IPc),"}  .",dot," "
       S tb=2 F i=1:1:$L(ruLst,",") S tok=$P(ruLst,",",i) DO  
         .S tb=tb+1 I dot=i W ?tb(tb),"  *  " S tb=tb+1
         .W ?tb(tb),tok," "
       W ?tb(7),$G(tokTy)," ",$G(tokR1)," "
       W ?tb(8)," {",IPs,"} "
       I $G(frm)'="" W ?tb(9),frm," "
       W:$X !
       Q
;*
Itab(WL)   KILL tb S tb=7  NEW w,i
       I $G(WL)="" S WL="3,3,10,15,15,15,15,20" ; ? something
       F i=1:1:$L(WL,",") S w=$P(WL,",",i),tb(i)=tb,tb=tb+w
       Q
;*  Write one item ala Lua Loup format for comparison
; WNa substitutes full Lua name
; @itemFL, Si,Sj,  runa, ruLst, dot, IPs
WLLua()  ;
       NEW runa,IPs,ruLst,dot,Lna,ti,tok
       W Lna," ",?8," -> "
       F ti=1:1:$L(ruLst,",")+1 S tok=$P(ruLst,",",ti) DO
         .I (dot)=ti W "  *  "
         .I tok="" Q  ; no more tok, extra to do dot at end
         .S ruid=$G(Gxi(runa,1)) I 'ruid S Q="Msg Lna of "_tok Q
         .S Lna=$G(GRk(ruid,"Lna"))
         .I Lna="" DO  ;
            ..D b^dv("Err Missing Lna of tok","tok,WNa,ti,rulst")
            ..S Lna=" ??? "
         .W Lna,"  "
       W ?50,"{",IPs,"}",!
       Q
;*
;*   INc()   Itb()
WIN   W:$X ! W !,"Inputs-"   NEW wi
      I $G(Ins) W !,"In str '",Ins,"'  "
      W !,"Ip: " F wi=1:1:INc W ?Itb(wi),wi," "
      W !,"lit " F wi=1:1:INc W ?Itb(wi),INc(wi)," "
      W !
      Q
;* Copy from ^dvs  same as ^dvc
	;Replace all dbl spaces (or more) with single, and remove starting/ending
DSP(X)	NEW i F i=0:1 Q:X'["  "  S X=$P(X,"  ")_" "_$P(X,"  ",2,9999)
	Q $$TSP(X)
	; Remove start and end spaces (only)
TSP(X)	NEW i S X=$TR(X,$C(9)_$C(10)_$C(13),"   ")  ;replace tab,lf,cr with space
	I $E($G(X))=" " F i=1:1:$L(X) I $E(X,i)'=" " S X=$E(X,i,999) Q
	I $E(X,$L(X))=" " F i=$L(X):-1:1 I $E(X,i)'=" " S X=$E(X,1,i) Q
	I X=" " S X=""  ; Funny case all spaces  vs end i=0 second line ?
	Q X
;*	
